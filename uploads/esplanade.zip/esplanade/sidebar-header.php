<?php if( is_active_sidebar( 1 ) ) : ?>
	<div id="sidebar-header" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 1 ); ?>
	</div><!-- #sidebar-header -->
<?php endif; ?>