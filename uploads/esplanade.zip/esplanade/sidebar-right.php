<?php if( is_active_sidebar( 4 ) ) : ?>
	<div id="sidebar-right" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 4 ) ; ?>
		<div class="clear"></div>
	</div><!-- #sidebar-right -->
<?php endif; ?>