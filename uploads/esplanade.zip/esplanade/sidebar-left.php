<?php if( is_active_sidebar( 3 ) ) : ?>
	<div id="sidebar-left" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 3 ) ; ?>
		<div class="clear"></div>
	</div><!-- #sidebar-left -->
<?php endif; ?>